package brinquedos;

import java.util.Scanner;

public class Brinquedos {
    static Scanner scan = new Scanner(System.in);

    public static void main(String[] args){
        ProdutoVet vet = new ProdutoVet(100);
        char opc;
        do{
            System.out.println("=== Loja de Brinquedos ===");
            System.out.println("1. Cadastrar produto");
            System.out.println("2. Listar todos");
            System.out.println("3. Listar produtos abaixo do estoque mínimo");
            System.out.println("4. Sair");
            System.out.print("Opção: ");
            opc = scan.next().charAt(0);
            scan.nextLine();

            switch(opc){
                case '1': cadastrar(vet); break;
                case '2': System.out.println(vet.toString()); break;
                case '3': System.out.println(vet.listarAbaixoMin()); break;
                case '4': System.out.println("Fim."); break;
            }
        } while(opc != '4');
    }

    static void cadastrar(ProdutoVet v){
        System.out.print("Código: ");
        int c = Integer.parseInt(scan.nextLine());
        System.out.print("Descrição: ");
        String d = scan.nextLine();
        System.out.print("Preço de compra: ");
        double pc = Double.parseDouble(scan.nextLine());
        System.out.print("Preço de venda: ");
        double pv = Double.parseDouble(scan.nextLine());
        System.out.print("Quantidade em estoque: ");
        int q = Integer.parseInt(scan.nextLine());
        System.out.print("Estoque mínimo: ");
        int m = Integer.parseInt(scan.nextLine());
        Produto p = new Produto(c, d, pc, pv, q, m);
        if(v.inserirDados(p)) System.out.println("Cadastrado.");
        else System.out.println("Cheio.");
    }
}
