package brinquedos;

public class ProdutoVet {
    private Produto[] vetor;
    private int quantVetor;

    public ProdutoVet(int tamanho){
        this.vetor = new Produto[tamanho];
        this.quantVetor = 0;
    }

    public Produto getVetor(int i){ return vetor[i]; }
    public int getQuantVetor(){ return quantVetor; }

    public boolean inserirDados(Produto p){
        if(quantVetor == vetor.length) return false;
        vetor[quantVetor++] = p;
        return true;
    }

    public int pesquisarPorCodigo(int codigo){
        for(int i=0;i<quantVetor;i++){
            if(vetor[i].getCodigo() == codigo) return i;
        }
        return quantVetor;
    }

    public String listarAbaixoMin(){
        String s = "";
        for(int i=0;i<quantVetor;i++)
            if(vetor[i].getQtdEstoque() < vetor[i].getEstoqueMin())
                s += vetor[i].toString() + "\n";
        return s;
    }

    @Override
    public String toString(){
        String s = "";
        for(int i=0;i<quantVetor;i++) s += vetor[i].toString() + "\n";
        return s;
    }
}
