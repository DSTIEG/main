package brinquedos;

public class Produto {
    private int codigo;
    private String descricao;
    private double precoCompra;
    private double precoVenda;
    private int qtdEstoque;
    private int estoqueMin;

    public Produto(int codigo, String descricao, double precoCompra, double precoVenda, int qtdEstoque, int estoqueMin){
        this.codigo = codigo;
        this.descricao = descricao;
        this.precoCompra = precoCompra;
        this.precoVenda = precoVenda;
        this.qtdEstoque = qtdEstoque;
        this.estoqueMin = estoqueMin;
    }

    public Produto(){ this(0, "", 0, 0, 0, 0); }

    public int getCodigo(){ return codigo; }
    public String getDescricao(){ return descricao; }
    public double getPrecoCompra(){ return precoCompra; }
    public double getPrecoVenda(){ return precoVenda; }
    public int getQtdEstoque(){ return qtdEstoque; }
    public int getEstoqueMin(){ return estoqueMin; }

    @Override
    public String toString(){
        return "Código: " + codigo + "\nDescrição: " + descricao + "\nCompra: " + precoCompra + "\nVenda: " + precoVenda + "\nQtd: " + qtdEstoque + "\nMin: " + estoqueMin + "\n";
    }
}
