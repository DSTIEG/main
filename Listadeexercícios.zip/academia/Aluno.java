package academia;

public class Aluno {
    private int matricula;
    private String nome;
    private double nota1;
    private double nota2;

    public Aluno(int matricula, String nome, double nota1, double nota2){
        this.matricula = matricula;
        this.nome = nome;
        this.nota1 = nota1;
        this.nota2 = nota2;
    }

    public Aluno(){ this(0, "", 0.0, 0.0); }

    public int getMatricula(){ return matricula; }
    public String getNome(){ return nome; }
    public double getNota1(){ return nota1; }
    public double getNota2(){ return nota2; }

    @Override
    public String toString(){
        return "Matrícula: " + matricula + "\nNome: " + nome + "\nNota1: " + nota1 + "\nNota2: " + nota2 + "\n";
    }
}
