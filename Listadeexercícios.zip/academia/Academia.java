package academia;

import java.util.Scanner;

public class Academia {
    static Scanner scan = new Scanner(System.in);

    public static void main(String[] args){
        AlunosVet vet = new AlunosVet(500);
        char opc;
        do{
            System.out.println("=== Sistema Acadêmico ===");
            System.out.println("1. Incluir aluno");
            System.out.println("2. Listar alunos com notas abaixo de X");
            System.out.println("3. Mostrar média de cada aluno");
            System.out.println("4. Sair");
            System.out.print("Opção: ");
            opc = scan.next().charAt(0);
            scan.nextLine();

            switch(opc){
                case '1': incluir(vet); break;
                case '2': listarAbaixo(vet); break;
                case '3': medias(vet); break;
                case '4': System.out.println("Fim."); break;
            }
        } while(opc != '4');
    }

    static void incluir(AlunosVet v){
        System.out.print("Matrícula: ");
        int m = Integer.parseInt(scan.nextLine());
        System.out.print("Nome: ");
        String n = scan.nextLine();
        System.out.print("Nota1: ");
        double n1 = Double.parseDouble(scan.nextLine());
        System.out.print("Nota2: ");
        double n2 = Double.parseDouble(scan.nextLine());
        Aluno a = new Aluno(m, n, n1, n2);
        if(v.inserirDados(a)) System.out.println("Cadastrado.");
        else System.out.println("Cheio.");
    }

    static void listarAbaixo(AlunosVet v){
        System.out.print("Valor limite: ");
        double x = Double.parseDouble(scan.nextLine());
        for(int i=0;i<v.getQuantVetor();i++){
            Aluno a = v.getVetor(i);
            if(a.getNota1() < x && a.getNota2() < x)
                System.out.println(a);
        }
    }

    static void medias(AlunosVet v){
        for(int i=0;i<v.getQuantVetor();i++){
            Aluno a = v.getVetor(i);
            double media = (a.getNota1() + a.getNota2()) / 2;
            System.out.println(a.getNome() + " - Média: " + media);
        }
    }
}
