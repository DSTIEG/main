package academia;

public class AlunosVet {
    private Aluno[] vetor;
    private int quantVetor;

    public AlunosVet(int tamanho){
        this.vetor = new Aluno[tamanho];
        this.quantVetor = 0;
    }

    public Aluno getVetor(int i){ return vetor[i]; }
    public int getQuantVetor(){ return quantVetor; }

    public boolean inserirDados(Aluno novo){
        if(quantVetor == vetor.length) return false;
        vetor[quantVetor++] = novo;
        return true;
    }

    @Override
    public String toString(){
        String s = "";
        for(int i=0;i<quantVetor;i++) s += (i+1) + ".\n" + vetor[i].toString() + "\n";
        return s;
    }
}
