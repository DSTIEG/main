package locadora;

import java.util.Scanner;

public class Locadora {
    static Scanner scan = new Scanner(System.in);

    public static void main(String[] args){
        char opc;
        FilmeVet loja = new FilmeVet(100); // pode ajustar o tamanho

        do{
            System.out.println("=== Locadora ===");
            System.out.println("1. Incluir filme");
            System.out.println("2. Mostrar todos");
            System.out.println("3. Contar por gênero");
            System.out.println("4. Excluir por título");
            System.out.println("5. Sair");
            System.out.print("Opção: ");
            opc = scan.next().charAt(0);
            scan.nextLine(); // limpar buffer

            switch(opc){
                case '1': incluirFilme(loja); break;
                case '2': System.out.println(loja.toString()); break;
                case '3': contarGenero(loja); break;
                case '4': excluirFilme(loja); break;
                case '5': System.out.println("Fim."); break;
                default: System.out.println("Opção inválida.");
            }
        } while(opc != '5');
    }

    static void incluirFilme(FilmeVet v){
        try {
            System.out.print("Código: ");
            int cod = Integer.parseInt(scan.nextLine());
            System.out.print("Título: ");
            String titulo = scan.nextLine();
            System.out.print("Gênero (A/T/D): ");
            char g = scan.nextLine().charAt(0);
            Filme f = new Filme(cod, titulo, g);
            if(v.inserirDados(f)) System.out.println("Filme cadastrado.");
            else System.out.println("Arquivo cheio.");
        } catch(Exception e){
            System.out.println("Entrada inválida. Operação cancelada.");
        }
    }

    static void contarGenero(FilmeVet v){
        System.out.print("Informe o gênero (A/T/D): ");
        char g = scan.nextLine().charAt(0);
        int qt = v.contarPorGenero(g);
        System.out.println("Total de filmes do gênero " + Character.toUpperCase(g) + ": " + qt);
    }

    static void excluirFilme(FilmeVet v){
        System.out.print("Informe o título do filme a excluir: ");
        String titulo = scan.nextLine();
        if(v.removerPorTitulo(titulo)) System.out.println("Removido com sucesso.");
        else System.out.println("Filme não encontrado.");
    }
}
