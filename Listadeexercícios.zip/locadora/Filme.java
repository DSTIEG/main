package locadora;

public class Filme {
	private int codigo;
	private String titulo;
	private char genero; // 'A' ação, 'T' terror, 'D' drama

	public Filme(int codigo, String titulo, char genero){
	   this.codigo = codigo;
	   this.titulo = titulo;
	   this.genero = Character.toUpperCase(genero);
	}

	public Filme(){
		this(0, "", 'A');
	}

	public int getCodigo(){ return codigo; }
	public String getTitulo1(){ return titulo; }
	public char getGenero(){ return genero; }

	public void setCodigo(int codigo){ this.codigo = codigo; }
	public void setTitulo(String titulo){ this.titulo = titulo; }
	public void setGenero(char genero){ this.genero = Character.toUpperCase(genero); }

	    @Override
	public String toString(){
	return "Código: " + codigo + "\nTítulo: " + titulo + "\nGênero: " + genero + "\n";
	}

		public String getTitulo() {
			// TODO Auto-generated method stub
			return null;
		}
}
