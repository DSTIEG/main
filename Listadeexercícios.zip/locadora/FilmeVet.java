package locadora;

public class FilmeVet {
    private Filme[] vetor;
    private int quantVetor;

    public FilmeVet(int tamanho){
        this.vetor = new Filme[tamanho];
        this.quantVetor = 0;
    }

    public Filme getVetor(int indice){ 
        return this.vetor[indice]; 
    }
    
    public void setVetor(int indice, Filme f){ 
        this.vetor[indice] = f; 
    }

    public int getQuantVetor(){ 
        return quantVetor; 
    }
    
    public void setQuantVetor(int novo){ 
        this.quantVetor = novo; 
    }

    @Override
    public String toString(){
        String resp = "";
        for(int i=0;i<this.quantVetor;i++){
            resp += (i+1) + ".\n" + this.vetor[i].toString() + "\n";
        }
        return resp;
    }

    public boolean inserirDados(Filme novo){
        if(this.quantVetor == this.vetor.length)
            return false;
        this.vetor[this.quantVetor] = novo;
        this.quantVetor++;
        return true;
    }

    public int pesquisarPorTitulo(String titulo){
        for(int i=0;i<this.quantVetor;i++){
            if(this.vetor[i].getTitulo().equalsIgnoreCase(titulo))
                return i;
        }
        return this.quantVetor;
    }

    public boolean removerPorTitulo(String titulo){
        if(this.quantVetor == 0)
            return false;

        int i = 0;
        while(i < this.quantVetor && 
             !this.vetor[i].getTitulo().equalsIgnoreCase(titulo)){
            i++;
        }

        if(i == this.quantVetor)
            return false;

        this.vetor[i] = this.vetor[this.quantVetor - 1];
        this.vetor[this.quantVetor - 1] = null;
        this.quantVetor--;
        return true;
    }

    public int contarPorGenero(char genero){
        genero = Character.toUpperCase(genero);
        int cont = 0;
        for(int i=0;i<this.quantVetor;i++){
            if(this.vetor[i].getGenero() == genero)
                cont++;
        }
        return cont;
    }
}
