package emprestimos;

import java.util.Scanner;

public class Emprestimos {
    static Scanner scan = new Scanner(System.in);

    public static void main(String[] args){
        EmprestimoVet vet = new EmprestimoVet(100);
        char opc;
        do{
            System.out.println("=== Sistema de Empréstimos ===");
            System.out.println("1. Cadastrar empréstimo");
            System.out.println("2. Listar todos");
            System.out.println("3. Alterar juros do maior empréstimo");
            System.out.println("4. Sair");
            System.out.print("Opção: ");
            opc = scan.next().charAt(0);
            scan.nextLine();

            switch(opc){
                case '1': cadastrar(vet); break;
                case '2': System.out.println(vet.toString()); break;
                case '3': alterarJuros(vet); break;
                case '4': System.out.println("Fim."); break;
            }
        } while(opc != '4');
    }

    static void cadastrar(EmprestimoVet v){
        System.out.print("Código: ");
        int c = Integer.parseInt(scan.nextLine());
        System.out.print("Cliente: ");
        String cli = scan.nextLine();
        System.out.print("Valor: ");
        double val = Double.parseDouble(scan.nextLine());
        System.out.print("Juros (%): ");
        double j = Double.parseDouble(scan.nextLine());
        Emprestimo e = new Emprestimo(c, cli, val, j);
        if(v.inserirDados(e)) System.out.println("Cadastrado.");
        else System.out.println("Cheio.");
    }

    static void alterarJuros(EmprestimoVet v){
        Emprestimo maior = v.maiorEmprestimo();
        if(maior == null){ 
            System.out.println("Nenhum empréstimo cadastrado."); 
            return; 
        }
        System.out.print("Novo juros (%): ");
        double novo = Double.parseDouble(scan.nextLine());
        maior.setJuros(novo);
        System.out.println("Alterado.\n" + maior);
    }
}
