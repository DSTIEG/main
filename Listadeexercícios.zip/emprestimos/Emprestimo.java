package emprestimos;

public class Emprestimo {
    private int codigo;
    private String cliente;
    private double valor;
    private double juros;

    public Emprestimo(int codigo, String cliente, double valor, double juros){
        this.codigo = codigo;
        this.cliente = cliente;
        this.valor = valor;
        this.juros = juros;
    }

    public Emprestimo(){ this(0, "", 0, 0); }

    public int getCodigo(){ return codigo; }
    public String getCliente(){ return cliente; }
    public double getValor(){ return valor; }
    public double getJuros(){ return juros; }

    public void setJuros(double juros){ this.juros = juros; }

    public double valorTotal(){ return valor + (valor * juros / 100); }

    @Override
    public String toString(){
        return "Código: " + codigo + "\nCliente: " + cliente + "\nValor: " + valor + "\nJuros: " + juros + "%" + "\nTotal: " + valorTotal() + "\n";
    }
}
