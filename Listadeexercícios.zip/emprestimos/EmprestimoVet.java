package emprestimos;

public class EmprestimoVet {
    private Emprestimo[] vetor;
    private int quantVetor;

    public EmprestimoVet(int tamanho){
        this.vetor = new Emprestimo[tamanho];
        this.quantVetor = 0;
    }

    public int getQuantVetor(){ return quantVetor; }
    public Emprestimo getVetor(int i){ return vetor[i]; }

    public boolean inserirDados(Emprestimo e){
        if(quantVetor == vetor.length) return false;
        vetor[quantVetor++] = e;
        return true;
    }

    public Emprestimo maiorEmprestimo(){
        if(quantVetor == 0) return null;
        Emprestimo maior = vetor[0];
        for(int i=1;i<quantVetor;i++)
            if(vetor[i].getValor() > maior.getValor()) maior = vetor[i];
        return maior;
    }

    @Override
    public String toString(){
        String s = "";
        for(int i=0;i<quantVetor;i++) s += vetor[i].toString() + "\n";
        return s;
    }
}
