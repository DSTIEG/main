package banco;

public class Conta {
    private int numero;
    private String cliente;
    private double saldo;

    public Conta(int numero, String cliente, double saldo){
        this.numero = numero;
        this.cliente = cliente;
        this.saldo = saldo;
    }

    public Conta(){ this(0, "", 0); }

    public int getNumero(){ return numero; }
    public String getCliente(){ return cliente; }
    public double getSaldo(){ return saldo; }

    @Override
    public String toString(){
        return "Número: " + numero + "\nCliente: " + cliente + "\nSaldo: " + saldo + "\n";
    }
}
