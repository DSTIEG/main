package banco;

public class ContaVet {
    private Conta[] vetor;
    private int quantVetor;

    public ContaVet(int tamanho){
        this.vetor = new Conta[tamanho];
        this.quantVetor = 0;
    }

    public int getQuantVetor(){ return quantVetor; }
    public Conta getVetor(int i){ return vetor[i]; }

    public boolean inserirDados(Conta c){
        if(quantVetor == vetor.length) return false;
        vetor[quantVetor++] = c;
        return true;
    }

    public void listarPorCliente(String nome){
        for(int i=0;i<quantVetor;i++)
            if(vetor[i].getCliente().equalsIgnoreCase(nome))
                System.out.println(vetor[i]);
    }

    public boolean excluirMenorSaldo(){
        if(quantVetor == 0) return false;
        int pos = 0;
        for(int i=1;i<quantVetor;i++)
            if(vetor[i].getSaldo() < vetor[pos].getSaldo()) pos = i;
        vetor[pos] = vetor[quantVetor - 1];
        vetor[quantVetor - 1] = null;
        quantVetor--;
        return true;
    }

    @Override
    public String toString(){
        String s = "";
        for(int i=0;i<quantVetor;i++) s += vetor[i].toString() + "\n";
        return s;
    }
}
