package banco;

import java.util.Scanner;

public class Banco {
    static Scanner scan = new Scanner(System.in);

    public static void main(String[] args){
        ContaVet vet = new ContaVet(100);
        char opc;
        do{
            System.out.println("=== Sistema Bancário ===");
            System.out.println("1. Cadastrar conta");
            System.out.println("2. Listar contas");
            System.out.println("3. Listar contas de um cliente");
            System.out.println("4. Excluir conta com menor saldo");
            System.out.println("5. Sair");
            System.out.print("Opção: ");
            opc = scan.next().charAt(0);
            scan.nextLine();

            switch(opc){
                case '1': cadastrar(vet); break;
                case '2': System.out.println(vet.toString()); break;
                case '3': listarCliente(vet); break;
                case '4': excluirMenor(vet); break;
                case '5': System.out.println("Fim."); break;
            }
        } while(opc != '5');
    }

    static void cadastrar(ContaVet v){
        System.out.print("Número: ");
        int n = Integer.parseInt(scan.nextLine());
        System.out.print("Cliente: ");
        String c = scan.nextLine();
        System.out.print("Saldo: ");
        double s = Double.parseDouble(scan.nextLine());
        Conta conta = new Conta(n, c, s);
        if(v.inserirDados(conta)) System.out.println("Cadastrado.");
        else System.out.println("Cheio.");
    }

    static void listarCliente(ContaVet v){
        System.out.print("Cliente: ");
        String nome = scan.nextLine();
        v.listarPorCliente(nome);
    }

    static void excluirMenor(ContaVet v){
        if(v.excluirMenorSaldo()) System.out.println("Conta removida.");
        else System.out.println("Nenhuma conta.");
    }
}
