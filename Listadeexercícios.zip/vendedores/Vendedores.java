package vendedores;

import java.util.Scanner;

public class Vendedores {
    static Scanner scan = new Scanner(System.in);

    public static void main(String[] args){
        VendedorVet vv = new VendedorVet(100);
        char opc;
        do{
            System.out.println("=== Vendedores ===");
            System.out.println("1. Incluir vendedor");
            System.out.println("2. Mostrar todos");
            System.out.println("3. Contar por tipo (P/N)");
            System.out.println("4. Excluir por nome");
            System.out.println("5. Sair");
            System.out.print("Opção: ");
            opc = scan.next().charAt(0);
            scan.nextLine();

            switch(opc){
                case '1': incluir(vv); break;
                case '2': System.out.println(vv.toString()); break;
                case '3': contarTipo(vv); break;
                case '4': excluirPorNome(vv); break;
                case '5': System.out.println("Fim."); break;
                default: System.out.println("Opção inválida.");
            }
        } while(opc != '5');
    }

    static void incluir(VendedorVet vv){
        try {
            System.out.print("Código: ");
            int codigo = Integer.parseInt(scan.nextLine());
            System.out.print("Nome: ");
            String nome = scan.nextLine();
            System.out.print("Tipo (P/N): ");
            char tipo = scan.nextLine().charAt(0);
            Vendedor v = new Vendedor(codigo, nome, tipo);
            if(vv.inserirDados(v)) System.out.println("Cadastrado.");
            else System.out.println("Arquivo cheio.");
        } catch(Exception e){
            System.out.println("Entrada inválida.");
        }
    }

    static void contarTipo(VendedorVet vv){
        System.out.print("Tipo (P/N): ");
        char tipo = scan.nextLine().charAt(0);
        int qtd = vv.contarPorTipo(tipo);
        System.out.println("Total do tipo " + Character.toUpperCase(tipo) + ": " + qtd);
    }

    static void excluirPorNome(VendedorVet vv){
        System.out.print("Nome: ");
        String nome = scan.nextLine();
        if(vv.removerPorNome(nome)) System.out.println("Removido.");
        else System.out.println("Não encontrado.");
    }
}
