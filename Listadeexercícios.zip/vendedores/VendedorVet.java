package vendedores;

public class VendedorVet {
    private Vendedor[] vetor;
    private int quantVetor;

    public VendedorVet(int tamanho){
        this.vetor = new Vendedor[tamanho];
        this.quantVetor = 0;
    }

    public Vendedor getVetor(int i){ return vetor[i]; }
    public int getQuantVetor(){ return quantVetor; }

    public boolean inserirDados(Vendedor novo){
        if(quantVetor == vetor.length) return false;
        vetor[quantVetor++] = novo;
        return true;
    }

    public int pesquisarPorNome(String nome){
        for(int i=0;i<quantVetor;i++){
            if(vetor[i].getNome().equalsIgnoreCase(nome)) return i;
        }
        return quantVetor;
    }

    public boolean removerPorNome(String nome){
        if(quantVetor == 0) return false;
        int i = 0;
        while(i < quantVetor && !vetor[i].getNome().equalsIgnoreCase(nome)) i++;
        if(i == quantVetor) return false;
        vetor[i] = vetor[quantVetor - 1];
        vetor[quantVetor - 1] = null;
        quantVetor--;
        return true;
    }

    public int contarPorTipo(char tipo){
        tipo = Character.toUpperCase(tipo);
        int cont = 0;
        for(int i=0;i<quantVetor;i++) if(vetor[i].getTipo() == tipo) cont++;
        return cont;
    }

    @Override
    public String toString(){
        String s = "";
        for(int i=0;i<quantVetor;i++) s += (i+1) + ".\n" + vetor[i].toString() + "\n";
        return s;
    }
}
