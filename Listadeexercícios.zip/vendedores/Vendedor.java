package vendedores;

public class Vendedor {
    private int codigo;
    private String nome;
    private char tipo;

    public Vendedor(int codigo, String nome, char tipo){
        this.codigo = codigo;
        this.nome = nome;
        this.tipo = Character.toUpperCase(tipo);
    }

    public Vendedor(){ this(0, "", 'N'); }

    public int getCodigo(){ return codigo; }
    public String getNome(){ return nome; }
    public char getTipo(){ return tipo; }

    public void setCodigo(int codigo){ this.codigo = codigo; }
    public void setNome(String nome){ this.nome = nome; }
    public void setTipo(char tipo){ this.tipo = Character.toUpperCase(tipo); }

    @Override
    public String toString(){
        return "Código: " + codigo + "\nNome: " + nome + "\nTipo: " + tipo + "\n";
    }
}
