package funcionarios;

public class FuncionarioVet {
    private Funcionario[] vetor;
    private int quantVetor;

    public FuncionarioVet(int tamanho){
        this.vetor = new Funcionario[tamanho];
        this.quantVetor = 0;
    }

    public int getQuantVetor(){ return quantVetor; }
    public Funcionario getVetor(int i){ return vetor[i]; }

    public boolean inserirDados(Funcionario f){
        if(quantVetor == vetor.length) return false;
        vetor[quantVetor++] = f;
        return true;
    }

    public boolean alterarHoras(int codigo, double novasHoras){
        for(int i=0;i<quantVetor;i++){
            if(vetor[i].getCodigo() == codigo){
                vetor[i].setHoras(novasHoras);
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString(){
        String s = "";
        for(int i=0;i<quantVetor;i++) s += vetor[i].toString() + "\n";
        return s;
    }
}
