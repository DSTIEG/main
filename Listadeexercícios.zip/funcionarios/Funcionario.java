package funcionarios;

public class Funcionario {
    private int codigo;
    private String nome;
    private char categoria;
    private double horas;
    private double valorHora;

    public Funcionario(int codigo, String nome, char categoria, double horas, double valorHora){
        this.codigo = codigo;
        this.nome = nome;
        this.categoria = Character.toUpperCase(categoria);
        this.horas = horas;
        this.valorHora = valorHora;
    }

    public Funcionario(){ this(0, "", 'N', 0, 0); }

    public int getCodigo(){ return codigo; }
    public String getNome(){ return nome; }
    public char getCategoria(){ return categoria; }
    public double getHoras(){ return horas; }
    public double getValorHora(){ return valorHora; }

    public void setHoras(double horas){ this.horas = horas; }

    public double salario(){
        double base = horas * valorHora;
        if(categoria == 'A') base *= 1.10;
        if(categoria == 'B') base *= 1.20;
        if(categoria == 'C') base *= 1.30;
        return base;
    }

    @Override
    public String toString(){
        return "Código: " + codigo + "\nNome: " + nome + "\nCategoria: " + categoria + "\nHoras: " + horas + "\nValor/hora: " + valorHora + "\nSalário: " + salario() + "\n";
    }
}
