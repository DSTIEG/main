package funcionarios;

import java.util.Scanner;

public class Funcionarios {
    static Scanner scan = new Scanner(System.in);

    public static void main(String[] args){
        FuncionarioVet vet = new FuncionarioVet(100);
        char opc;
        do{
            System.out.println("=== Sistema de Funcionários ===");
            System.out.println("1. Cadastrar funcionário");
            System.out.println("2. Alterar horas trabalhadas");
            System.out.println("3. Listar todos");
            System.out.println("4. Sair");
            System.out.print("Opção: ");
            opc = scan.next().charAt(0);
            scan.nextLine();

            switch(opc){
                case '1': cadastrar(vet); break;
                case '2': alterarHoras(vet); break;
                case '3': System.out.println(vet.toString()); break;
                case '4': System.out.println("Fim."); break;
            }
        } while(opc != '4');
    }

    static void cadastrar(FuncionarioVet v){
        System.out.print("Código: ");
        int c = Integer.parseInt(scan.nextLine());
        System.out.print("Nome: ");
        String n = scan.nextLine();
        System.out.print("Categoria (A/B/C): ");
        char cat = scan.nextLine().charAt(0);
        System.out.print("Horas: ");
        double h = Double.parseDouble(scan.nextLine());
        System.out.print("Valor da hora: ");
        double vh = Double.parseDouble(scan.nextLine());
        Funcionario f = new Funcionario(c, n, cat, h, vh);
        if(v.inserirDados(f)) System.out.println("Cadastrado.");
        else System.out.println("Cheio.");
    }

    static void alterarHoras(FuncionarioVet v){
        System.out.print("Código: ");
        int c = Integer.parseInt(scan.nextLine());
        System.out.print("Novas horas: ");
        double h = Double.parseDouble(scan.nextLine());
        if(v.alterarHoras(c, h)) System.out.println("Alterado.");
        else System.out.println("Funcionário não encontrado.");
    }
}
